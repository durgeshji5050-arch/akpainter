import './globals.css';
import type { Metadata } from 'next';
export const metadata:Metadata={title:'AK Painters — Professional Design & Printing',description:'AK Painters business and school ID card management'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}

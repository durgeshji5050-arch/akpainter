import CustomerOrderForm from './CustomerOrderForm';
import Link from 'next/link';

const services=[
 {icon:'🎓',title:'School ID Cards',text:'Student ID card design, data entry and bulk production workflow.'},
 {icon:'💍',title:'Wedding Cards',text:'Invitation cards and personalized print-ready designs.'},
 {icon:'💼',title:'Business Printing',text:'Business cards, flyers, posters, banners and stationery.'},
 {icon:'🎨',title:'Graphic Design',text:'Professional custom artwork for personal and business needs.'},
];

export default function Home(){return <main className="public-home">
 <nav className="public-nav"><Link href="/" className="public-brand"><span className="brand-dot">AK</span><span><b>AK Painters</b><small>Designer & Printing Studio</small></span></Link><div className="public-nav-links"><a href="#services">Services</a><a href="#workflow">How it works</a><Link href="/login" className="public-login">School Login →</Link></div></nav>
 <section className="public-hero">
  <div className="hero-copy"><span className="eyebrow">DESIGN • PRINT • MANAGE</span><h1>Your complete <em>design & printing</em> workspace.</h1><p>From school ID cards to wedding invitations, business printing and custom graphics — manage your work through one professional platform.</p><div className="public-actions"><a href="#customer-order" className="public-primary">Customer Order <span>→</span></a><Link href="/login" className="public-secondary">School Login</Link><a href="#services" className="public-secondary">Explore Services</a></div><div className="trust-row"><span>✓ School ID Cards</span><span>✓ Bulk Excel / PDF</span><span>✓ Admin-controlled printing</span></div></div>
  <div className="hero-art"><div className="art-card art-main"><span className="art-label">AK PAINTERS</span><strong>Creative<br/>Work<br/>Studio</strong><div className="art-line"/><small>DESIGN • PRINT • DELIVER</small></div><div className="art-card art-mini"><b>56 × 85.8</b><span>ID Card mm</span></div><div className="art-circle">AK</div></div>
 </section>
 <CustomerOrderForm />
 <section id="services" className="public-section"><div className="section-intro"><span className="eyebrow">WHAT WE DO</span><h2>One studio. Multiple creative services.</h2><p>Designed for schools, businesses and individual customers.</p></div><div className="service-grid">{services.map(s=><article className="service-card" key={s.title}><div className="service-icon">{s.icon}</div><h3>{s.title}</h3><p>{s.text}</p><span className="service-arrow">Explore →</span></article>)}</div></section>
 <section id="workflow" className="workflow"><div><span className="eyebrow">SIMPLE WORKFLOW</span><h2>From request to production, everything stays organized.</h2></div><div className="steps"><div><b>01</b><strong>Submit</strong><p>Create a request or upload student data.</p></div><div><b>02</b><strong>Review</strong><p>Choose a service, design and required details.</p></div><div><b>03</b><strong>Produce</strong><p>AK Painters handles the final production workflow.</p></div></div></section>
 <footer className="public-footer"><div><b>AK Painters</b><span>Professional Design & Printing</span></div><div className="footer-links"><a href="#customer-order">Customer Order →</a><Link href="/login">School Login →</Link></div></footer>
 </main>}

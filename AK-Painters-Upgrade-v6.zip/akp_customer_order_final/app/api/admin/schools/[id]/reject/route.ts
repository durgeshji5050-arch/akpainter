import {NextResponse} from 'next/server';
import {db} from '@/lib/db';
import {getSession} from '@/lib/auth';
export async function POST(_req:Request,{params}:{params:Promise<{id:string}>}){const s=await getSession();if(!s||s.role!=='ADMIN')return NextResponse.json({error:'Admin login required'},{status:401});const {id}=await params;const school=await db.school.update({where:{id},data:{status:'REJECTED'}});return NextResponse.json({ok:true,status:school.status});}

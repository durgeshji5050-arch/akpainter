import {NextResponse} from 'next/server';
import {db} from '@/lib/db';
import {getSession} from '@/lib/auth';
async function admin(){const s=await getSession();return s?.role==='ADMIN';}
const aliases:Record<string,string>={idCardRate:'service_rate_school_id_cards',weddingCardRate:'service_rate_wedding_cards',businessCardRate:'service_rate_business_printing',graphicDesignRate:'service_rate_graphic_design',otherRate:'service_rate_other',adminWhatsapp:'admin_whatsapp'};
const reverse:Record<string,string>={service_rate_school_id_cards:'idCardRate',service_rate_wedding_cards:'weddingCardRate',service_rate_business_printing:'businessCardRate',service_rate_graphic_design:'graphicDesignRate',service_rate_other:'otherRate',admin_whatsapp:'adminWhatsapp'};
export async function GET(){if(!await admin())return NextResponse.json({error:'Admin only'},{status:403});const rows=await db.appSetting.findMany();const settings:Record<string,string>={};for(const r of rows)settings[reverse[r.key]||r.key]=r.value||'';return NextResponse.json(settings)}
export async function POST(req:Request){if(!await admin())return NextResponse.json({error:'Admin only'},{status:403});const body=await req.json();for(const [key,value] of Object.entries(body)){if(typeof value!=='string')continue;const dbKey=aliases[key]||key;if(!/^[a-zA-Z0-9_]{1,80}$/.test(dbKey))continue;await db.appSetting.upsert({where:{key:dbKey},update:{value},create:{key:dbKey,value}})}return NextResponse.json({ok:true})}
